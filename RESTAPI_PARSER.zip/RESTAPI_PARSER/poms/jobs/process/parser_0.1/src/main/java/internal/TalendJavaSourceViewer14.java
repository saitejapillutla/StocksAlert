package internal;

import routines.DataOperation;
import routines.Mathematical;
import routines.Numeric;
import routines.Relational;
import routines.StringHandling;
import routines.TalendDataGenerator;
import routines.TalendDate;
import routines.TalendString;
import routines.TalendStringUtil;
import routines.system.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;

@SuppressWarnings("unused")

public class TalendJavaSourceViewer14 {
	private static java.util.Properties context = new java.util.Properties();
	private static final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	public void myFunction(){
	  if( 

String wholepage; 
String ratings; 
wholepage=input_row.document.toString(); 
int pos=wholepage.indexOf("composite_val"); 
ratings=wholepage.substring(pos,pos+250).replaceAll("[\\[\\]\"]", "").replaceAll(" \n", " ").replaceAll(" composite_val_vgm",""); 
//output_row.document = ratings; 
String allratingsonly=""; 
String[] splitratings = ratings.split("composite_val>"); 
int i =0;
for (String eachratingrow : splitratings) 
{ 
	if (i>=4){

   if (eachratingrow.length()>0)
   { allratingsonly=allratingsonly+";"+ eachratingrow.charAt(0)+"";
   //     allratingsonly=allratingsonly+eachratingrow+"**;"; 
    } 
    }else{ i++;}
} 
output_row.document=allratingsonly;

// code sample:
//
// multiply by 2 the row identifier
// output_row.id = input_row.id * 2;
//
// lowercase the name
// output_row.name = input_row.name.toLowerCase();


){
	}
	
}
}